from PIL import Image, ImageDraw
import os

OUTPUT_DIR = "/home/claude/mcdonalds-mod/src/main/resources/assets/mcdonaldsmod/textures/item"

# Each item: (name, bg_color, detail_color, shape)
ITEMS = {
    "big_mac":        ((139, 90, 43), (220, 180, 90), "burger"),
    "mc_chicken":     ((220, 180, 90), (255, 255, 255), "burger"),
    "mc_nuggets":     ((220, 160, 50), (200, 130, 30), "nuggets"),
    "large_fries":    ((255, 200, 0), (230, 100, 0), "fries"),
    "mc_flurry":      ((255, 255, 255), (150, 100, 60), "cup"),
    "apple_pie":      ((210, 150, 80), (160, 100, 40), "pie"),
    "filet_o_fish":   ((180, 220, 150), (255, 255, 200), "burger"),
    "quarter_pounder":((160, 80, 20), (220, 180, 90), "burger"),
    "happy_meal":     ((255, 60, 0), (255, 200, 0), "box"),
    "cola":           ((30, 10, 10), (80, 40, 20), "cup"),
    "mc_rib":         ((160, 60, 20), (220, 140, 80), "rib"),
    "shamrock_shake": ((50, 180, 70), (100, 220, 120), "cup"),
}

def draw_texture(name, bg, detail, shape):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    if shape == "burger":
        # bun top
        d.ellipse([2, 1, 13, 6], fill=bg)
        # patty
        d.rectangle([1, 6, 14, 9], fill=detail)
        # bun bottom
        d.ellipse([2, 9, 13, 14], fill=bg)
    elif shape == "nuggets":
        # draw 3 nuggets
        d.ellipse([1, 1, 6, 6], fill=bg)
        d.ellipse([8, 1, 14, 7], fill=detail)
        d.ellipse([3, 8, 10, 14], fill=bg)
    elif shape == "fries":
        # container
        d.rectangle([3, 8, 12, 14], fill=(220, 60, 0))
        # fries
        for x in [4, 6, 8, 10]:
            d.rectangle([x, 2, x+1, 9], fill=bg)
    elif shape == "cup":
        # cup body
        d.polygon([(3, 4), (12, 4), (11, 14), (4, 14)], fill=bg)
        # lid
        d.rectangle([2, 2, 13, 5], fill=detail)
        # straw
        d.rectangle([9, 0, 10, 5], fill=(255, 100, 100))
    elif shape == "pie":
        d.ellipse([2, 2, 13, 13], fill=bg)
        d.arc([2, 2, 13, 13], 0, 90, fill=detail, width=2)
        d.line([(7, 7), (13, 7)], fill=detail, width=1)
        d.line([(7, 7), (7, 13)], fill=detail, width=1)
    elif shape == "box":
        # box
        d.rectangle([2, 5, 13, 14], fill=bg)
        # lid open
        d.rectangle([2, 3, 13, 6], fill=detail)
        # M logo
        d.text((4, 6), "M", fill=(255, 255, 255))
    elif shape == "rib":
        # bone
        d.rectangle([2, 6, 13, 9], fill=detail)
        d.ellipse([1, 4, 5, 10], fill=(230, 200, 180))
        d.ellipse([10, 4, 14, 10], fill=(230, 200, 180))

    path = os.path.join(OUTPUT_DIR, f"{name}.png")
    img.save(path)
    print(f"Created {path}")

for name, (bg, detail, shape) in ITEMS.items():
    draw_texture(name, bg, detail, shape)

print("All textures created!")

package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;

public class McNuggetsItem extends Item {

    private static final Food MC_NUGGETS_FOOD = new Food.Builder()
            .hunger(5)
            .saturation(0.5f)
            .build();

    public McNuggetsItem(Properties properties) {
        super(properties.food(MC_NUGGETS_FOOD));
    }
}

package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;

public class McChickenItem extends Item {

    private static final Food MC_CHICKEN_FOOD = new Food.Builder()
            .hunger(6)
            .saturation(0.6f)
            .build();

    public McChickenItem(Properties properties) {
        super(properties.food(MC_CHICKEN_FOOD));
    }
}

package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;

public class BigMacItem extends Item {

    private static final Food BIG_MAC_FOOD = new Food.Builder()
            .hunger(8)
            .saturation(0.8f)
            .effect(() -> new EffectInstance(Effects.REGENERATION, 100, 0), 0.5f)
            .build();

    public BigMacItem(Properties properties) {
        super(properties.food(BIG_MAC_FOOD));
    }
}

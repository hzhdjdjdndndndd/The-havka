package com.mcdonaldsmod.mcdonaldsmod.init;

import com.mcdonaldsmod.mcdonaldsmod.McDonaldsMod;
import com.mcdonaldsmod.mcdonaldsmod.item.*;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, McDonaldsMod.MOD_ID);

    // Big Mac
    public static final RegistryObject<Item> BIG_MAC = ITEMS.register("big_mac",
            () -> new BigMacItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16)));

    // McChicken
    public static final RegistryObject<Item> MC_CHICKEN = ITEMS.register("mc_chicken",
            () -> new McChickenItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16)));

    // McNuggets (6 pack)
    public static final RegistryObject<Item> MC_NUGGETS = ITEMS.register("mc_nuggets",
            () -> new McNuggetsItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16)));

    // Large Fries
    public static final RegistryObject<Item> LARGE_FRIES = ITEMS.register("large_fries",
            () -> new LargeFriesItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16)));

    // McFlurry (Oreo)
    public static final RegistryObject<Item> MC_FLURRY = ITEMS.register("mc_flurry",
            () -> new McFlurryItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(1)));

    // Apple Pie
    public static final RegistryObject<Item> APPLE_PIE = ITEMS.register("apple_pie",
            () -> new ApplePieItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16)));

    // Filet-O-Fish
    public static final RegistryObject<Item> FILET_O_FISH = ITEMS.register("filet_o_fish",
            () -> new FiletOFishItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16)));

    // Quarter Pounder
    public static final RegistryObject<Item> QUARTER_POUNDER = ITEMS.register("quarter_pounder",
            () -> new QuarterPounderItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16)));

    // Happy Meal Box
    public static final RegistryObject<Item> HAPPY_MEAL = ITEMS.register("happy_meal",
            () -> new HappyMealItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(1)));

    // Soft Drink (Cola)
    public static final RegistryObject<Item> COLA = ITEMS.register("cola",
            () -> new ColaItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16)));

    // McRib (seasonal!)
    public static final RegistryObject<Item> MC_RIB = ITEMS.register("mc_rib",
            () -> new McRibItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16)));

    // Shamrock Shake (gives speed effect)
    public static final RegistryObject<Item> SHAMROCK_SHAKE = ITEMS.register("shamrock_shake",
            () -> new ShamrockShakeItem(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(1)));
}

package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;

public class ApplePieItem extends Item {

    private static final Food APPLE_PIE_FOOD = new Food.Builder()
            .hunger(4)
            .saturation(0.5f)
            .build();

    public ApplePieItem(Properties properties) {
        super(properties.food(APPLE_PIE_FOOD));
    }
}

package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;

public class LargeFriesItem extends Item {

    private static final Food LARGE_FRIES_FOOD = new Food.Builder()
            .hunger(5)
            .saturation(0.4f)
            .effect(() -> new EffectInstance(Effects.SLOWNESS, 60, 0), 0.2f)
            .build();

    public LargeFriesItem(Properties properties) {
        super(properties.food(LARGE_FRIES_FOOD));
    }
}

package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;

public class HappyMealItem extends Item {

    private static final Food HAPPY_MEAL_FOOD = new Food.Builder()
            .hunger(7)
            .saturation(0.7f)
            .effect(() -> new EffectInstance(Effects.SPEED, 200, 0), 1.0f)
            .effect(() -> new EffectInstance(Effects.JUMP_BOOST, 200, 0), 1.0f)
            .effect(() -> new EffectInstance(Effects.REGENERATION, 100, 0), 1.0f)
            .build();

    public HappyMealItem(Properties properties) {
        super(properties.food(HAPPY_MEAL_FOOD));
    }
}

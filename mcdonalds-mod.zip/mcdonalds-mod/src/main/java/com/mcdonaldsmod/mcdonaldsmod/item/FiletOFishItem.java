package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;

public class FiletOFishItem extends Item {

    private static final Food FILET_O_FISH_FOOD = new Food.Builder()
            .hunger(6)
            .saturation(0.6f)
            .build();

    public FiletOFishItem(Properties properties) {
        super(properties.food(FILET_O_FISH_FOOD));
    }
}

package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;

public class QuarterPounderItem extends Item {

    private static final Food QUARTER_POUNDER_FOOD = new Food.Builder()
            .hunger(10)
            .saturation(0.9f)
            .effect(() -> new EffectInstance(Effects.REGENERATION, 150, 1), 0.6f)
            .build();

    public QuarterPounderItem(Properties properties) {
        super(properties.food(QUARTER_POUNDER_FOOD));
    }
}

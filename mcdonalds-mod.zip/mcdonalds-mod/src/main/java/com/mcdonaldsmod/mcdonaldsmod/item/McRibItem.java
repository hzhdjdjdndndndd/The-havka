package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;

public class McRibItem extends Item {

    private static final Food MC_RIB_FOOD = new Food.Builder()
            .hunger(9)
            .saturation(0.85f)
            .effect(() -> new EffectInstance(Effects.STRENGTH, 200, 0), 0.7f)
            .build();

    public McRibItem(Properties properties) {
        super(properties.food(MC_RIB_FOOD));
    }
}

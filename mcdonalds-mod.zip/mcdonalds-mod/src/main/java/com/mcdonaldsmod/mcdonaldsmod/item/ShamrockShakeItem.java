package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;

public class ShamrockShakeItem extends Item {

    private static final Food SHAMROCK_SHAKE_FOOD = new Food.Builder()
            .hunger(4)
            .saturation(0.5f)
            .effect(() -> new EffectInstance(Effects.SPEED, 400, 1), 1.0f)
            .effect(() -> new EffectInstance(Effects.JUMP_BOOST, 400, 1), 1.0f)
            .build();

    public ShamrockShakeItem(Properties properties) {
        super(properties.food(SHAMROCK_SHAKE_FOOD));
    }
}

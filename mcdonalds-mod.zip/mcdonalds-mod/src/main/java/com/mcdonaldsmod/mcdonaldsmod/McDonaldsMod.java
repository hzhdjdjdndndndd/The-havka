package com.mcdonaldsmod.mcdonaldsmod;

import com.mcdonaldsmod.mcdonaldsmod.init.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(McDonaldsMod.MOD_ID)
public class McDonaldsMod {
    public static final String MOD_ID = "mcdonaldsmod";
    public static final Logger LOGGER = LogManager.getLogger();

    public McDonaldsMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modEventBus);
        LOGGER.info("McDonald's Mod loaded! Ba da ba ba baaa!");
    }
}

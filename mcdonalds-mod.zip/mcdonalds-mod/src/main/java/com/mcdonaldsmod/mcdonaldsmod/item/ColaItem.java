package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;

public class ColaItem extends Item {

    private static final Food COLA_FOOD = new Food.Builder()
            .hunger(2)
            .saturation(0.2f)
            .effect(() -> new EffectInstance(Effects.HASTE, 120, 0), 0.8f)
            .build();

    public ColaItem(Properties properties) {
        super(properties.food(COLA_FOOD));
    }
}

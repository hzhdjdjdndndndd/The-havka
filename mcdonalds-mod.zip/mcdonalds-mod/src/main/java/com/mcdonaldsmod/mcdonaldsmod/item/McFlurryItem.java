package com.mcdonaldsmod.mcdonaldsmod.item;

import net.minecraft.item.Food;
import net.minecraft.item.Item;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;

public class McFlurryItem extends Item {

    private static final Food MC_FLURRY_FOOD = new Food.Builder()
            .hunger(4)
            .saturation(0.6f)
            .effect(() -> new EffectInstance(Effects.SPEED, 200, 0), 1.0f)
            .build();

    public McFlurryItem(Properties properties) {
        super(properties.food(MC_FLURRY_FOOD));
    }
}
